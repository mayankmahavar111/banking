# banking
Pyhton/django based banking system. most of the features covered into it, with some extras.
you should have django install in your computer otherwise you have to install in order to run it
run following command in cmd/terminal of current folder

pip install django-allauth(this is to install some files regarding django)

python manage.py makemigrations

pyhton manage.py migrate

to run the website each time execute this command

python manage.py runserver

then visit 127.0.0.1:8000/chkbal



This project is not complete yet, it will be updating regularly before final stage.
